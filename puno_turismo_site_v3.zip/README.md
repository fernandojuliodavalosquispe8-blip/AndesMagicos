# Turismo en Puno 🌄

Sitio web estático sobre los principales atractivos de Puno, optimizado para GitHub Pages.

## Estructura
- `index.html`: Página principal con TailwindCSS y AOS (animaciones).

## Cómo publicar en GitHub Pages
1. Crea un nuevo repositorio en GitHub.
2. Sube los archivos (`index.html` y este `README.md`).
3. En la configuración del repositorio, activa **GitHub Pages** desde la rama `main`.
4. Accede a tu página en: `https://tuusuario.github.io/nombre-repo/`

